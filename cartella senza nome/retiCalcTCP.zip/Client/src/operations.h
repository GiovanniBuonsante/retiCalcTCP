/*
 * operations.h
 *
 *  Created on: 2 dic 2023
 *      Author: giovannibuonsante
 */
#ifndef PROVACALCTCP_OPERATIONS_H
#define PROVACALCTCP_OPERATIONS_H

///declaration of the operation
int add(int num1, int num2);
int subtract(int num1, int num2);
int multiply(int num1, int num2);
int divide(int num1, int num2);

#endif //PROVACALCTCP_OPERATIONS_H
